package com.ng.RoasterSpringboot.repository;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Query;

@Repository
public class RoasterDataRepository {
	@Autowired
	EntityManager entityManager;
	@Autowired
	private EntityManagerFactory entityManagerFactory;
	
	
	public String insertDataRoaster(ArrayList data_row) {
	EntityManager em = entityManagerFactory.createEntityManager();
	String query ="insert into [healthcare].[dbo].[ROASTER_DATA] "
			+ " (Provider_Type,First_Name,Middle_Name,Last_name,Gender,Suffix,Delegated,Directory,CAQHID,NPI,DOB,MedicareID,Accepting_New,EmailID,Legal_Entity_Name,Contract_ID,DBA_Name,License_Number,License_State,License_Type,License_Expiration_Date,Speciality,Taxonomy,PCP,Medical_Group_Name,Language_Spoken,Location_Address_1,Location_Address_2,Location_City,Location_County,Location_State,Location_Zip_Code,Office_Phone,Office_Fax,Public_Transportation,Handicap_Access,TTY_Hearing,TTY_Phone,Tele_Medicine,TaxID,PaytoName,Payto_Address_1,Payto_Address_2,Payto_City,Payto_County,Payto_State,Payto_Zip_Code,PaytoNPI) "
			+ " values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
	String success ="";
	em.getTransaction().begin();
	//in loop
	Query insert= em.createNativeQuery(query);
	for(int i= 0;i<data_row.size();i++)
	{
		int j = i+1;
		insert.setParameter(j, data_row.get(i));
		
	}	
	int result = insert.executeUpdate();
	em.getTransaction().commit();
	if(result>0)
	{
		success="s";
	}
	return success;
	}
}
