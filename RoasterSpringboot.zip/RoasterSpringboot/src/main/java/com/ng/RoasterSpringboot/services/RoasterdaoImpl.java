package com.ng.RoasterSpringboot.services;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ng.RoasterSpringboot.repository.RoasterDataRepository;


@Service
public class RoasterdaoImpl implements Roasterdao{
	
	@Autowired
	RoasterDataRepository repo;
	@Override
	public String insertData(ArrayList DataRow) {
		
		String res = repo.insertDataRoaster(DataRow);
		
		return res;
	}

	

}
