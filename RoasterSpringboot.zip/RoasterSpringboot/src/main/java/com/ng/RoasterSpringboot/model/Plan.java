package com.ng.RoasterSpringboot.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name ="Plan")
public class Plan {
	@Id
	private long plan_id;
	private String plan_name;
	
	public Plan() {
		
	}
	
	public Plan(String plan_name) {
		super();
		this.plan_name = plan_name;
	}
	public long getPlan_id() {
		return plan_id;
	}
	public void setPlan_id(long plan_id) {
		this.plan_id = plan_id;
	}
	public String getPlan_name() {
		return plan_name;
	}
	public void setPlan_name(String plan_name) {
		this.plan_name = plan_name;
	}
}
