package com.ng.RoasterSpringboot.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import lombok.Builder;

@Entity
@Table(name ="Request_plan")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class PlanData {
	@Id
	private long request_id;
	private long request_plan_id;
	private String request_plan_name;
	private String Company_name;
	
	public PlanData() {
		
	}
	
	public long getRequest_id() {
		return request_id;
	}

	public void setRequest_id(long request_id) {
		this.request_id = request_id;
	}

	public long getRequest_plan_id() {
		return request_plan_id;
	}

	public void setRequest_plan_id(long request_plan_id) {
		this.request_plan_id = request_plan_id;
	}

	public String getRequest_plan_name() {
		return request_plan_name;
	}

	public void setRequest_plan_name(String request_plan_name) {
		this.request_plan_name = request_plan_name;
	}

	public String getCompany_name() {
		return Company_name;
	}

	public void setCompany_name(String company_name) {
		Company_name = company_name;
	}

	
	
	
}
