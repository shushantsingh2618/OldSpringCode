package com.ng.RoasterSpringboot.repository;

public interface PlanDataRepository {

}
