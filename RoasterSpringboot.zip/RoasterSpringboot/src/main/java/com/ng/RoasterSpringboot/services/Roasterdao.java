package com.ng.RoasterSpringboot.services;

import java.util.ArrayList;

public interface Roasterdao {
	
public String insertData(ArrayList DataRow);
	

}
