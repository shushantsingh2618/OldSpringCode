package com.ng.RoasterSpringboot.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ng.RoasterSpringboot.model.Plan;
import com.ng.RoasterSpringboot.repository.PlanRepository;
import com.ng.RoasterSpringboot.services.Roasterdao;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.log4j.Logger;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
//import java.util.logging.Logger;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Row.MissingCellPolicy;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import com.sun.net.httpserver.HttpServer;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpExchange;
import javax.servlet.*;
import javax.servlet.annotation.*;
import javax.servlet.http.*;

@RestController
@RequestMapping("api/")
public class PlanController {
	
	@Autowired
	private PlanRepository planRepository;
	
	@Autowired
	private Roasterdao Services;
	
	@GetMapping("Plan")
	public String getplan(){
		return "This is Testing";
	}
	
	@PostMapping("Planpost")
	public String postplan(){
		String Test = StartProcess();
		return "This is Post Testing";
		
	}
	@GetMapping("Rosterget")
	public String StartProcess()
	{
		String fileName= "DelegatedRoster.xlsx";
		String fName = "D:\\workspace\\RosterFile\\";
	//Put the header number from excel where all header is present
	int headerPos = Integer.parseInt("2");
	File file = new File(fName);
	if(!file.exists()) {
		file.mkdirs();
	}
	
	 fileName = file.listFiles()[0].getName();
	 String type = fileName.substring(fileName.lastIndexOf(".")+1,fileName.length()).trim();
	 if(type.equalsIgnoreCase("xls") || type.equalsIgnoreCase("xlsx")) {
			String filePath = file.getAbsolutePath() + "\\" + fileName;
			LinkedHashMap<Integer, ArrayList<String>> excelData = new LinkedHashMap();
			//System.out.println("FilePath: "+filePath);
			if(type.equalsIgnoreCase("xls")) {
				excelData = readXLS(filePath,headerPos);
			}
			if(type.equalsIgnoreCase("xlsx")) {
				excelData = readXLSX(filePath,headerPos);
			}

}
	 return "success";
	}
	 
	 
	 
	 @SuppressWarnings("deprecation")
		public LinkedHashMap<Integer, ArrayList<String>> readXLS(String sFileName,int headerPos)
		{
		  //System.out.println("reading xls file-" + sFileName);
		  LinkedHashMap<Integer, ArrayList<String>> data = new LinkedHashMap();
		  //System.out.println("reading xls file-" + sFileName);
		  int startRow = 0;
		  FileInputStream fileInputStream = null;
		  try
		  {
		    fileInputStream = new FileInputStream(sFileName);
		    HSSFWorkbook workbook = new HSSFWorkbook(fileInputStream);
		    HSSFSheet worksheet = workbook.getSheetAt(0);

		    boolean stop = false;

		    Row lastRow = null;
		    Cell cell = null;

		    while (!(stop)) {
		      boolean nonBlankRowFound = false;
		      lastRow = worksheet.getRow(worksheet.getLastRowNum());
		      for (int c = lastRow.getFirstCellNum(); c <= lastRow.getLastCellNum(); c++) {
		    	 try {
		        cell = lastRow.getCell(c);
		        if ((cell != null)) {
		          nonBlankRowFound = true;
		        }
		    	 }catch(Exception e) {
		    		 //System.out.println("Inside For Exception: "+e.getMessage());
		    	 }
		      }
		      if (nonBlankRowFound)
		        stop = true;
		      else {
		        worksheet.removeRow(lastRow);
		      }

		    }

		    //int noOfRowsInExcel = worksheet.getPhysicalNumberOfRows();
		    //System.out.println("noOfRowsInExcel=" + noOfRowsInExcel);
		    //System.out.println("11");
		    
		    String cellVal = null;
		    //String columnName = this.constants.get("Source_File_" + this.srcIndex + "_DEST_TABLE_COLUMNS");
		    //System.out.println("columnName=" + columnName);
		    //int noOfcol = columnName.length() - columnName.replace(",", "").length();
		    //System.out.println("No Of Columns to read..." + noOfcol);
		    //System.out.println("No Of Columns to read..." + noOfcol);
		    //headers_length=noOfcol;
		    int rownumber = 0;
		    int count = 0;

		    for (rownumber = 1; rownumber <= headerPos; ++rownumber)
		    {
		      ArrayList data_row = new ArrayList();

		      HSSFRow row = worksheet.getRow(rownumber);
		      System.out.println("rownumber=" + (rownumber+1));
		      if ((row == null) || 
		        (rownumber < startRow)) {
		        continue;
		      }
		      int lastColumn = row.getLastCellNum();
				//System.out.println("row.getLastCellNum()=" + row.getLastCellNum());
				//System.out.println("lastColumn=" + lastColumn);
		      for (int cn = 0; cn < lastColumn; ++cn) {
		    	worksheet.autoSizeColumn(cn);
		        cell = row.getCell(cn, MissingCellPolicy.CREATE_NULL_AS_BLANK);
		        //System.out.println("Column no=" + (cn + 1));

		        if (cell == null) {
		          data_row.add("");
				  
		        }
		        
		        else
		        {
		        	
		          DataFormatter formatter = new DataFormatter();
		          cellVal = formatter.formatCellValue(cell);
		          data_row.add(cellVal);
		          
		          //
		          System.out.println("cell= " + cell);
		          System.out.println("cellVal= " + cellVal);
		          
		          
		          if (HSSFDateUtil.isCellDateFormatted(cell)) {
		                System.out.println("The cell contains a date value: "
		                        + cell.getDateCellValue());
		            }
		          //
		          
		          
		        }
		      }
		      String var1 = Services.insertData(data_row);
		      data.put(Integer.valueOf(count), data_row);
		      ++count;
		    }
		    
		    System.out.println("Harshit data "+data);
		    System.out.println("data length"+data.size());
		            
		  }
		  catch (IOException e)
		  {
		    System.out.println("Error in reading XLS File IOException" + e.getMessage());
		    //insertSuccess(sFileName,false);
		  }
		  catch (Exception e)
		  {
		    System.out.println("Error in reading XLS File Exception" + e.getMessage());
		    //insertSuccess(sFileName,false);
		  }
		  finally
		  {
		    try
		    {
		      fileInputStream.close();
		    }
		    catch (IOException e)
		    {
		      System.out.println("Error in reading XLS File" + e.getMessage());
		    }
		  }
		  return data;
		}
	 private static final Map<String, String> DATE_FORMAT_REGEXPS = new HashMap<String, String>() {{
		   
			// put("^\\d{8}$", "yyyyMMdd");	yyyy-dd-mm
			 put("^\\d{1,2}-\\d{1,2}-\\d{4}$", "dd-MM-yyyy");
			 put("^\\d{4}-\\d{1,2}-\\d{1,2}$", "yyyy-MM-dd");		//Yyyy-mm-dd 2012-06-21
			 
			 put("^(0[1-9]|1[0-2])\\/(0[1-9]|1\\d|2\\d|3[01])\\/(19|20)\\d{2}$", "MM/dd/yyyy"); 
			 put("^([0-2][0-9]|(3)[0-1])(\\/)(((0)[0-9])|((1)[0-2]))(\\/)\\d{4}$","dd/MM/yyyy");
			 //put("^([0-2][0-9]||3[0-1])/(0[0-9]||1[0-2])/([0-9][0-9])?[0-9][0-9]$","dd/MM/yyyy");
			
			 
			 put("^\\d{4}/\\d{1,2}/\\d{1,2}$", "yyyy/MM/dd");
			 put("^\\d{1,2}\\s[a-z]{3}\\s\\d{4}$", "dd MMM yyyy");
			 put("^\\d{1,2}\\s[a-z]{4,}\\s\\d{4}$", "dd MMMM yyyy");
			 put("^\\d{1,2}-[a-z]{3}-\\d{4}$", "dd-MMM-yyyy");		//added 24-Mar-2014
		    //put("^\\d{1,2}.\\d{1,2}.\\d{4}$", "MM.dd.yyyy");		//added 
		    // testing
		   // put("(0?[1-9]|[12][0-9]|3[01])/(0?[1-9]|1[012])/((?:19|20)[0-9][0-9])",);
		    //
		    
		   // put("^\\d{12}$", "yyyyMMddHHmm");
		   // put("^\\d{8}\\s\\d{4}$", "yyyyMMdd HHmm");
		    put("^\\d{1,2}-\\d{1,2}-\\d{4}\\s\\d{1,2}:\\d{2}$", "dd-MM-yyyy HH:mm");
		    put("^\\d{4}-\\d{1,2}-\\d{1,2}\\s\\d{1,2}:\\d{2}$", "yyyy-MM-dd HH:mm");
		    put("^\\d{1,2}/\\d{1,2}/\\d{4}\\s\\d{1,2}:\\d{2}$", "MM/dd/yyyy HH:mm");
		    put("^\\d{4}/\\d{1,2}/\\d{1,2}\\s\\d{1,2}:\\d{2}$", "yyyy/MM/dd HH:mm");
		    put("^\\d{1,2}\\s[a-z]{3}\\s\\d{4}\\s\\d{1,2}:\\d{2}$", "dd MMM yyyy HH:mm");
		    put("^\\d{1,2}\\s[a-z]{4,}\\s\\d{4}\\s\\d{1,2}:\\d{2}$", "dd MMMM yyyy HH:mm");
		  //  put("^\\d{14}$", "yyyyMMddHHmmss");
		  //  put("^\\d{8}\\s\\d{6}$", "yyyyMMdd HHmmss");
		    put("^\\d{1,2}-\\d{1,2}-\\d{4}\\s\\d{1,2}:\\d{2}:\\d{2}$", "dd-MM-yyyy HH:mm:ss");
		    put("^\\d{4}-\\d{1,2}-\\d{1,2}\\s\\d{1,2}:\\d{2}:\\d{2}$", "yyyy-MM-dd HH:mm:ss");
		    put("^\\d{1,2}/\\d{1,2}/\\d{4}\\s\\d{1,2}:\\d{2}:\\d{2}$", "MM/dd/yyyy HH:mm:ss");
		    put("^\\d{4}/\\d{1,2}/\\d{1,2}\\s\\d{1,2}:\\d{2}:\\d{2}$", "yyyy/MM/dd HH:mm:ss");
		    put("^\\d{1,2}\\s[a-z]{3}\\s\\d{4}\\s\\d{1,2}:\\d{2}:\\d{2}$", "dd MMM yyyy HH:mm:ss");
		    put("^\\d{1,2}\\s[a-z]{4,}\\s\\d{4}\\s\\d{1,2}:\\d{2}:\\d{2}$", "dd MMMM yyyy HH:mm:ss");
		}};
	 public static String determineDateFormat(String dateString) {
		    for (String regexp : DATE_FORMAT_REGEXPS.keySet()) {
		        if (dateString.toLowerCase().matches(regexp)) {
		            return DATE_FORMAT_REGEXPS.get(regexp);
		        }
		    }
		    return null; // Unknown format.
		}
	 
	 public  LinkedHashMap<Integer, ArrayList<String>> readXLSX(String sFileName,int headerPos)
		{
		 // System.out.println("reading xlsx file-" + sFileName);
		  //System.out.println("reading xls file-" + sFileName);
		  FileInputStream fileInputStream = null;
		  LinkedHashMap<Integer, ArrayList<String>> data = new LinkedHashMap();
		  try
		  {
			int startRow = 0;
		    data = new LinkedHashMap();
		    fileInputStream = new FileInputStream(sFileName);
		    XSSFWorkbook workbook = new XSSFWorkbook(fileInputStream);
		    XSSFSheet worksheet = workbook.getSheetAt(0);
		    
		    

		    boolean stop = false;

		    XSSFRow lastRow = null;
		    XSSFCell cell = null;

		    while (!(stop)) {
		      boolean nonBlankRowFound = false;
		      lastRow = worksheet.getRow(worksheet.getLastRowNum());
		      for (int c = lastRow.getFirstCellNum(); c <= lastRow.getLastCellNum(); c++) {
		        cell = lastRow.getCell(c);
		        if ((cell != null)) {
		          nonBlankRowFound = true;
		        }
		      }
		      if (nonBlankRowFound)
		        stop = true;
		      else {
		        worksheet.removeRow(lastRow);
		      }

		    }

		    //int noOfRowsInExcel = worksheet.getPhysicalNumberOfRows();
		    //System.out.println("noOfRowsInExcel=" + noOfRowsInExcel);
		    System.out.println("11");
		    
		    String cellVal = null;
		    //String columnName = this.props.getProperty("Source_File_" + this.srcIndex + "_DEST_TABLE_COLUMNS");
		    //System.out.println("columnName=" + columnName);
		    //int noOfcol = columnName.length() - columnName.replace(",", "").length();
		    //System.out.println("No Of Columns to read..." + noOfcol);
		    //System.out.println("No Of Columns to read..." + noOfcol);
		    //headers_length=noOfcol;
		    int rownumber = 0;
		    int count = 0;

		    for (rownumber = 1; rownumber <= headerPos; ++rownumber)
		    {
		      ArrayList data_row = new ArrayList();

		      XSSFRow row = worksheet.getRow(rownumber);
		      System.out.println("rownumber=" + (rownumber+1));
		      if ((row == null) || 
		        (rownumber < startRow)) {
		        continue;
		      }
		      int lastColumn = row.getLastCellNum();
				//System.out.println("row.getLastCellNum()=" + row.getLastCellNum());
				//System.out.println("lastColumn=" + lastColumn);
		      for (int cn = 0; cn < lastColumn; ++cn) {
		    	worksheet.autoSizeColumn(cn);
		        cell = row.getCell(cn, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK);
		        //System.out.println("Column no=" + (cn + 1));
		        //
		        
		        //

		        if (cell == null) {
		          data_row.add("");
				  
		        }
		        
		        else
		        {
		        	
		        	CellType cell_type=cell.getCellType();
		        	 if(cell.getCellType() == CellType.STRING) {
		        		 String functioncall=determineDateFormat(cell.toString());
		        		 System.out.println("function call determine date  " + functioncall);
		        		 if (functioncall != null) {
		        			 
		        			 DataFormatter formatter = new DataFormatter();
		        			 cellVal = formatter.formatCellValue(cell);
		        			 System.out.println("inside the loop cell date newdate value cellval " + cellVal);
		        			 
		        			 DateFormat parser = new SimpleDateFormat(functioncall);
							 Date date = (Date) parser.parse(cell.toString());
							 
							 SimpleDateFormat SP = new SimpleDateFormat("MM/dd/yyyy");
						        String newdate = SP.format(date);
						        data_row.add(newdate);
						        System.out.println("inside the loop cell date newdate value " + cell);
						        System.out.println("inside the loop cell date newdate " + newdate);
		        		 }
		        		 else {
		        			 DataFormatter formatter = new DataFormatter();
							 cellVal = formatter.formatCellValue(cell);
							 if((cellVal.equalsIgnoreCase("yes")) || (cellVal.equalsIgnoreCase("Y"))) {
								 cellVal="true";
							 }
							 if((cellVal.equalsIgnoreCase("no")) || (cellVal.equalsIgnoreCase("N"))) {
								 cellVal="false";
							 }
							 //if(p.toString().equalsIgnoreCase("Behavioral Health")) {
								//p="BehavioralHealth";
							//}
							 
							 data_row.add(cellVal);
							 System.out.println("inside the loop cellVal " + cellVal);
		        		 }
		        		 
		        		 /*
		        		 System.out.println("only number1");
		        		 String abc1=cell.toString();
		        		 System.out.println("abc1" + abc1);
						String abc=cell.toString().replace("/","").replace("-","");
						//abc.replace("/","");
						 System.out.println("abc" + abc);
						if(abc.matches("[0-9]+")) {
							if(abc1.contains("/")) {
								 System.out.println("inside /////");
							 System.out.println("only number3");
							 System.out.println("inside the loop cell " + cell);
							 
							 String functioncall=determineDateFormat(cell.toString());
							 System.out.println("function call determine date  " + functioncall);
							 
							 
							 //DateFormat parser = new SimpleDateFormat("MM/dd/yyyy");
							 DateFormat parser = new SimpleDateFormat(functioncall);
							 Date date = (Date) parser.parse(abc1);
							 
							 SimpleDateFormat SP = new SimpleDateFormat("MM/dd/yyyy");
						        String newdate = SP.format(date);
						
							 System.out.println("inside the loop cell date " + date);
							 System.out.println("inside the loop  " + date);
							 System.out.println("inside the loop cell date newdate " + newdate);
							 
							 data_row.add(newdate);
		
							}
							
							
						}
						else {
							DataFormatter formatter = new DataFormatter();
							 cellVal = formatter.formatCellValue(cell);
							 data_row.add(cellVal);
								}
			        	  System.out.println("inside numeric " + cell.getCellType());
			        	*/
			          }
		        	
		        	 else {   //numerics,blank
		        		 if(cell.getCellType() == CellType.NUMERIC) {
		        			 String functioncall=determineDateFormat(cell.toString());
		        			 System.out.println("inside the loop cell date newdate numerics11 " + functioncall);
		        			 if (functioncall != null) {
		        				 DateFormat parser = new SimpleDateFormat(functioncall);
								 Date date = (Date) parser.parse(cell.toString());
								 
								 SimpleDateFormat SP = new SimpleDateFormat("MM/dd/yyyy");
							        String newdate = SP.format(date);
							        data_row.add(newdate);
							        System.out.println("inside the loop cell date newdate numerics " + newdate);
		        			 }
		        			 else {
		        				 DataFormatter formatter = new DataFormatter();
								 cellVal = formatter.formatCellValue(cell);
								 data_row.add(cellVal);
								 System.out.println("inside the loop cellVal numerics else " + cell);
								 System.out.println("inside the loop cellVal numerics else cell val " + cellVal);
		        			 }
		        			 
		        		 }	
		        		 else {
		        		  DataFormatter formatter = new DataFormatter();
		   	   	         
		   	   	          cellVal = formatter.formatCellValue(cell);
		   	   	          
		   	   	          System.out.println("cell= " + cell);
		   	   	          
		   	   	          System.out.println("celltype " + cell.getCellType());
		   	   	          System.out.println("cellVal= " + cellVal);

		   	   	         
		   	   	          data_row.add(cellVal);
		        			 
		        		// }

		        		 }
		        	 }
		        	 

		        	
		     
		        /*	
		          DataFormatter formatter = new DataFormatter();
		          //cell.setCellType(1);
		        	  //System.out.println("Inside XLS else="+cell);
		          cellVal = formatter.formatCellValue(cell);
		          //added
		          System.out.println("cell= " + cell);
		          
		          System.out.println("celltype " + cell.getCellType());
		          System.out.println("cellVal= " + cellVal);

		         
		          data_row.add(cellVal);
		          */
		         
		        }
		      }
		      String var1 = Services.insertData(data_row);
		      data.put(Integer.valueOf(count), data_row);
		      ++count;
		    }
		    
		    System.out.println("Harshit data "+data);
		    System.out.println("data length"+data.size());
		            
		  }
		  catch (IOException e)
		  {
		    System.out.println("Error in reading XLSX File IOException" + e.getMessage());
		    //insertSuccess(sFileName,false);
		  }
		  catch (Exception e)
		  {
		    System.out.println("Error in reading XLSX File Exception" + e.getMessage());
		    //insertSuccess(sFileName,false);
		  }
		  finally
		  {
		    try
		    {
		      fileInputStream.close();
		    }
		    catch (IOException e)
		    {
		      System.out.println("Error in reading XLSX File" + e.getMessage());
		    }
		  }
		  return data;
		}

	 public static void addDataXLSX(String sFileName,int headerPos) throws InvalidFormatException, IOException
	 {
		 String fileName= "Roster Data";
			String fName = "D:\\workspace\\RosterFile\\";
			File file = new File(fName);
		 //Create Workbook instance holding reference to .xlsx file
	        XSSFWorkbook workbook = new XSSFWorkbook(file);

	        //Get first/desired sheet from the workbook
	        XSSFSheet sheet = workbook.getSheetAt(0);
	        int totalRows = sheet.getPhysicalNumberOfRows();
	        ArrayList data_row = new ArrayList();
	        

	        //Iterate through each rows one by one
	        Iterator<Row> rowIterator = sheet.iterator();
	        int headerRow = sheet.getFirstRowNum();
	        while (rowIterator.hasNext())
	        {
	            Row row = rowIterator.next();
	            //For each row, iterate through all the columns
	            Iterator<Cell> cellIterator = row.cellIterator();

	            while (cellIterator.hasNext()) 
	            {
	                Cell cell = cellIterator.next();
	                //Check the cell type and format accordingly
	                switch (cell.getCellType()) 
	                {
	                    case NUMERIC:
	                        System.out.print(cell.getNumericCellValue() + "\t");
	                        data_row.add(cell.getStringCellValue());
	                        //break;
	                    case STRING:
	                        System.out.print(cell.getStringCellValue() + "\t");
	                        data_row.add(cell.getStringCellValue());
	                       // break;
	                }
	            }
	            System.out.println("");
	 }
	 }
	 static class UploadHandler implements HttpHandler {
	        @Override
	        public void handle(HttpExchange exchange) throws IOException {
	            if ("POST".equals(exchange.getRequestMethod())) {
	                InputStream requestBody = exchange.getRequestBody();
	                // Handle the file (e.g., read or process the Excel file)
	                // For simplicity, let's just print the file name
	                String fileName = exchange.getRequestHeaders().getFirst("excelFile");
	                System.out.println("Uploaded file name: " + fileName);

	                // You can add code here to read/process the Excel file

	                String response = "File uploaded successfully: " + fileName;
	                exchange.sendResponseHeaders(200, response.length());
	                OutputStream responseBody = exchange.getResponseBody();
	                responseBody.write(response.getBytes());
	                responseBody.close();
	            } else {
	                exchange.sendResponseHeaders(405, 0); // Method Not Allowed
	            }
	        }
	    }
}
