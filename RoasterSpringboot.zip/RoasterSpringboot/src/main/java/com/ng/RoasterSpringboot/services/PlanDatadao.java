package com.ng.RoasterSpringboot.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import com.ng.RoasterSpringboot.repository.PlanDataRepository;

import com.ng.RoasterSpringboot.model.PlanData;

@Service
public class PlanDatadao {
	
	@Autowired
	private PlanDatadao repository;
	/*public String uploadExcel(MultipartFile file){
	repository.save(PlanData.builder()
			.name(file.getOriginalFilename())
			.type(type.file.getContentType()).
			request_plan_name(request_plan_name: file.getBytes().build());
			)
	}*/

}
