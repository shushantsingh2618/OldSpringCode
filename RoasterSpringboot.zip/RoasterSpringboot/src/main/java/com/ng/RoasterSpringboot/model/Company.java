package com.ng.RoasterSpringboot.model;

import jakarta.persistence.Id;

public class Company {
	@Id
	private long company_id;
	private String company_name;
	
	public Company() {
		
	}
	
	public Company(String company_name) {
		super();
		this.company_name = company_name;
	}
	public long getCompany_id() {
		return company_id;
	}
	public void setCompany_id(long company_id) {
		this.company_id = company_id;
	}
	public String getCompany_name() {
		return company_name;
	}
	public void setCompany_name(String company_name) {
		this.company_name = company_name;
	}
}
